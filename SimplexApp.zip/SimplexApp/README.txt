BUILD THE APK
1. Install Android Studio (developer.android.com/studio).
2. File > Open > select this SimplexApp folder. Wait for "Gradle sync" to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. File: app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone, tap it, allow "Install unknown apps", install.

TO CHANGE THE PAGE: replace app/src/main/assets/index.html and rebuild.
If Gradle sync fails: File > New > New Project > "Empty Views Activity"
(Java, package com.simplex.solver), then copy over MainActivity.java,
AndroidManifest.xml, and the assets/index.html file.
